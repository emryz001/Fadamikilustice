# Fada Miki Justice - Wisdom Refinery Ministry Website

## Overview
This is a complete website with Netlify CMS integration, allowing you to easily add sermons, articles, and events without coding.

## Features
- ✅ Dynamic sermon management
- ✅ Article/blog posting
- ✅ Event calendar
- ✅ Prayer request forms
- ✅ Newsletter signup
- ✅ Responsive design
- ✅ Admin panel at `/admin`

## File Structure
```
├── _config.yml          # Site configuration
├── index.html           # Homepage
├── _layouts/
│   └── default.html     # Main layout template
├── _sermons/            # Sermon content (managed by CMS)
├── _posts/              # Article content (managed by CMS)
├── _events/             # Event content (managed by CMS)
├── admin/
│   ├── index.html       # CMS login page
│   └── config.yml       # CMS configuration
└── images/              # Image uploads
```

## Setup Instructions

### Step 1: Create GitHub Repository
1. Go to https://github.com
2. Create new repository (e.g., "fada-miki-website")
3. Upload all these files to the repository

### Step 2: Deploy to Netlify
1. Go to https://netlify.com
2. Sign up (free)
3. Click "New site from Git"
4. Choose GitHub and select your repository
5. Click "Deploy site"

### Step 3: Enable Identity (Login System)
1. In Netlify dashboard, go to "Identity"
2. Click "Enable Identity"
3. Go to "Settings" → "Identity" → "Registration"
4. Set to "Invite only" (recommended)
5. Go to "Services" → "Git Gateway"
6. Click "Enable Git Gateway"

### Step 4: Add Yourself as Admin
1. In Netlify Identity tab, click "Invite users"
2. Enter your email
3. Accept the invitation in your email
4. Set your password

### Step 5: Access Admin Panel
1. Go to `https://your-site-name.netlify.app/admin`
2. Login with your credentials
3. Start adding content!

## Using the Admin Panel

### Adding a Sermon
1. Go to Admin → Sermons
2. Click "New Sermon"
3. Fill in:
   - Title
   - Date
   - YouTube Video ID (just the ID, not full URL)
   - Description
   - Tags
4. Click "Publish"

### Adding an Article
1. Go to Admin → Articles
2. Click "New Article"
3. Use the rich text editor to write
4. Add featured image (optional)
5. Click "Publish"

### Adding an Event
1. Go to Admin → Events
2. Click "New Event"
3. Fill in event details
4. Click "Publish"

### Updating Contact Info
1. Go to Admin → Site Settings
2. Update phone, email, social links
3. Changes apply immediately

## Important Notes

### YouTube Video ID
- Full URL: `https://youtube.com/watch?v=dQw4w9WgXcQ`
- Just the ID: `dQw4w9WgXcQ`
- Paste only the ID in the admin panel

### Images
- Upload images through the admin panel
- They'll be stored in `images/uploads/`
- Recommended size: 1200x800 pixels

### Prayer Requests
- Currently set up with Formspree
- Sign up at https://formspree.io
- Replace `YOUR_FORM_ID` in index.html with your actual form ID

## Customization

### Change Colors
Edit `_layouts/default.html` and modify the CSS variables:
```css
:root {
    --primary-color: #1a237e;    /* Navy Blue */
    --secondary-color: #c9a227;  /* Gold */
}
```

### Change Mass Times
Edit `index.html` directly or update through site settings

## Support
For help with Netlify CMS, visit: https://www.netlifycms.org/docs/

## Contact
Fada Miki Justice
- Phone: 08064658729
- Email: mikijustice73@gmail.com
- Facebook: https://www.facebook.com/mike.onum
- YouTube: https://youtube.com/@mikijustice8380
