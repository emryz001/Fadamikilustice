---
title: "Sunday Mass with Fada Miki"
day: "SUN"
month: "Weekly"
time: "6:00 AM, 8:00 AM, 10:00 AM"
description: "Join us for the celebration of the Holy Eucharist every Sunday. Experience the grace of the Mass and uplifting homilies."
featured: true
---
